#!/usr/bin/env python3
"""Create .env once, with generated secrets; never print or overwrite them."""
import os
from pathlib import Path
import secrets

root = Path(__file__).resolve().parents[1]
target = root / ".env"
content = (root / ".env.example").read_text()
for name in ("GRAFANA_ADMIN_PASSWORD", "INFLUXDB_ADMIN_PASSWORD",
             "INFLUXDB_READ_PASSWORD", "INFLUXDB_WRITE_PASSWORD"):
    content = content.replace(f"{name}=\n", f"{name}={secrets.token_hex(24)}\n")
try:
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
except FileExistsError:
    print(".env already exists; unchanged.")
else:
    with os.fdopen(fd, "w") as output:
        output.write(content)
    print("Created .env (0600). Set TELEGRAF_HOST and Grafana connection settings before starting.")
