#!/usr/bin/env python3
"""Validate any number of Classic dashboards in projects/, including subfolders."""
import sys
import tomllib

from dashboard_io import ROOT, DashboardError, project_dashboards, validate_collection


def main():
    try:
        dashboards = list(project_dashboards(ROOT / "projects"))
        validate_collection(dashboards)
        tomllib.loads((ROOT / "monitoring/telegraf/telegraf.conf").read_text())
    except (DashboardError, ValueError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(f"OK: {len(dashboards)} dashboard(s); JSON, unique UIDs/titles, nested panel IDs, datasource variables and Telegraf TOML.")
    print("Datasource connectivity, installed plugins and queries must be checked in Grafana.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
