#!/usr/bin/env python3
"""Build the server dashboard using only the documented Telegraf fields."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DS = {"type": "influxdb", "uid": "${DS_INFLUXDB}"}
HOST = '"host" =~ /^${host:regex}$/'
DISK = '"device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/'
IO = '"name" =~ /^${diskio_device:regex}$/'
NET = '"interface" =~ /^${interface:regex}$/'
ALL = {"text": ["All"], "value": ["$__all"]}


def variable(name, label, measurement, tag, condition=None):
    query = f'SHOW TAG VALUES FROM "{measurement}"'
    query += f' WITH KEY = "{tag}"'
    if condition:
        query += f" WHERE {condition}"
    return {"name": name, "label": label, "type": "query", "datasource": DS,
            "query": query, "definition": query, "refresh": 1, "sort": 1,
            "multi": True, "includeAll": True, "allValue": ".*",
            "current": ALL, "options": []}


def query(measurement, expression, tags=(), condition=None):
    group = ', '.join(['time($interval)', '"host"'] + [f'"{t}"' for t in tags])
    where = HOST + (f" AND {condition}" if condition else "")
    return (f'SELECT {expression} FROM "{measurement}" WHERE $timeFilter AND {where} '
            f'GROUP BY {group} fill(null)')


def mean(field):
    return f'mean("{field}")'


def rate(field):
    return f'non_negative_derivative(last("{field}"), 1s)'


panels = []


def panel(title, measurement, expressions, unit, *, tags=(), condition=None,
          percent=False, critical=False, stat=False, description="", pos=None):
    targets = []
    alias_tags = ' '.join(f'[[tag_{tag}]]' for tag in ('host', *tags))
    for i, (name, expression) in enumerate(expressions):
        targets.append({"refId": chr(65 + i), "datasource": DS,
                        "rawQuery": True, "resultFormat": "time_series",
                        "query": query(measurement, f'{expression} AS "{name}"', tags, condition),
                        "alias": f"{alias_tags} · {name}"})
    steps = [{"color": "green", "value": None}]
    if percent:
        steps += [{"color": "yellow", "value": 80}, {"color": "red", "value": 90}]
    elif critical:
        steps += [{"color": "red", "value": 1}]
    defaults = {"unit": unit, "min": 0, "decimals": 1,
                "thresholds": {"mode": "absolute", "steps": steps},
                "color": {"mode": "thresholds" if stat else "palette-classic"},
                "mappings": []}
    if percent:
        defaults["max"] = 100
    if stat:
        options = {"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False},
                   "colorMode": "value", "graphMode": "none", "textMode": "auto",
                   "orientation": "auto", "justifyMode": "auto", "wideLayout": True}
    else:
        defaults["custom"] = {"drawStyle": "line", "lineInterpolation": "linear",
                              "lineWidth": 1, "fillOpacity": 10, "spanNulls": False,
                              "showPoints": "never", "stacking": {"mode": "none", "group": "A"},
                              "thresholdsStyle": {"mode": "dashed" if percent or critical else "off"}}
        options = {"legend": {"displayMode": "table", "placement": "bottom",
                              "showLegend": True, "calcs": ["lastNotNull", "max"]},
                   "tooltip": {"mode": "multi", "sort": "desc"}}
    if pos is None:
        index = len(panels) - 5
        pos = {"x": (index % 2) * 12, "y": 5 + (index // 2) * 8, "w": 12, "h": 8}
    panels.append({"id": len(panels) + 1, "type": "stat" if stat else "timeseries",
                   "title": title, "description": description,
                   "datasource": DS, "gridPos": pos, "interval": "10s",
                   "fieldConfig": {"defaults": defaults, "overrides": []},
                   "options": options, "targets": targets})


CPU = '"cpu" = \'cpu-total\''
BUSY = '100 - mean("usage_idle")'
for title, measurement, expressions, unit, tags, condition, is_pct, x, w in [
    ("CPU %", "cpu", [("busy", BUSY)], "percent", ("cpu",), CPU, True, 0, 5),
    ("RAM %", "mem", [("used", mean("used_percent"))], "percent", (), None, True, 5, 5),
    ("Disk % by mount", "disk", [("used", mean("used_percent"))], "percent", ("device", "path"), DISK, True, 10, 5),
    ("Load Average (1m)", "system", [("load1", mean("load1"))], "short", (), None, False, 15, 5),
    ("Uptime", "system", [("uptime", 'last("uptime")')], "s", (), None, False, 20, 4),
]:
    panel(title, measurement, expressions, unit, tags=tags, condition=condition,
          percent=is_pct, stat=True, pos={"x": x, "y": 0, "w": w, "h": 5},
          description="Last non-null bucket in the selected time range, separately for each series. Check time range and collector freshness if the host stops reporting.")

panel("CPU total utilization", "cpu", [("busy", BUSY)], "percent", tags=("cpu",), condition=CPU, percent=True)
panel("CPU utilization by core", "cpu", [("busy", BUSY)], "percent", tags=("cpu",), condition='"cpu" != \'cpu-total\'', percent=True)
panel("CPU modes", "cpu", [(f, mean("usage_" + f)) for f in ("user", "system", "idle")], "percent", tags=("cpu",), condition=CPU, percent=True)
panel("CPU I/O wait", "cpu", [("iowait", mean("usage_iowait"))], "percent", tags=("cpu",), condition=CPU, percent=True,
      description="Percentage of CPU time waiting for I/O; the generic 80/90 thresholds may need lower values for your workload.")
panel("Memory capacity", "mem", [(f, mean(f)) for f in ("used", "available", "total")], "bytes")
panel("Memory utilization", "mem", [("used", mean("used_percent"))], "percent", percent=True)
panel("Swap capacity", "swap", [(f, mean(f)) for f in ("used", "free", "total")], "bytes")
panel("Swap utilization", "swap", [("used", mean("used_percent"))], "percent", percent=True,
      description="Hosts without swap may report zero or no series. Missing data is not filled with zero.")
panel("Disk capacity by mount", "disk", [(f, mean(f)) for f in ("used", "free", "total")], "bytes", tags=("device", "path"), condition=DISK)
panel("Disk utilization by mount", "disk", [("used", mean("used_percent"))], "percent", tags=("device", "path"), condition=DISK, percent=True)
panel("Inodes by mount", "disk", [(f, mean(f)) for f in ("inodes_used", "inodes_free")], "short", tags=("device", "path"), condition=DISK)
panel("Inode utilization by mount", "disk", [("used", '100 * mean("inodes_used") / (mean("inodes_used") + mean("inodes_free"))')], "percent", tags=("device", "path"), condition=DISK + ' AND ("inodes_used" > 0 OR "inodes_free" > 0)', percent=True,
      description="Used / (used + free). Filesystems reporting no inodes are excluded to avoid division by zero.")
panel("Disk I/O throughput", "diskio", [(f, rate(f + "_bytes")) for f in ("read", "write")], "Bps", tags=("name",), condition=IO,
      description="Non-negative rate of cumulative bytes, grouped by host and device. Counter resets create gaps; the first bucket needs a preceding sample.")
panel("Disk I/O accumulated time rate", "diskio", [(f, rate(f + "_time")) for f in ("read", "write")], "suffix:ms/s", tags=("name",), condition=IO,
      description="Rate of cumulative read_time/write_time (milliseconds per second). This is NOT latency per operation or disk utilization; concurrent requests may exceed 1000 ms/s. Operation counters are not in the supplied schema.")
panel("Network traffic", "net", [("receive", rate("bytes_recv")), ("send", rate("bytes_sent"))], "Bps", tags=("interface",), condition=NET)
panel("Network packets", "net", [("receive", rate("packets_recv")), ("send", rate("packets_sent"))], "pps", tags=("interface",), condition=NET)
panel("Network errors", "net", [("in", rate("err_in")), ("out", rate("err_out"))], "suffix:errors/s", tags=("interface",), condition=NET, critical=True,
      description="Counter rate; red at >= 1 error/s. Smaller positive rates are still worth investigating.")
panel("Network drops", "net", [("in", rate("drop_in")), ("out", rate("drop_out"))], "suffix:drops/s", tags=("interface",), condition=NET, critical=True)
panel("Processes", "processes", [(f, mean(f)) for f in ("total", "running", "sleeping")], "short")
panel("Blocked and zombie processes", "processes", [(f, mean(f)) for f in ("blocked", "zombies")], "short", critical=True)
panel("Load averages", "system", [(f, mean(f)) for f in ("load1", "load5", "load15")], "short",
      description="Runnable/uninterruptible tasks, not a percentage. Compare with logical CPU count; no universal absolute threshold is applied.")
panel("Logged-in users", "system", [("users", mean("n_users"))], "short")

dashboard = {
    "id": None, "uid": "skynet-server-resources", "title": "Server Resources Overview",
    "description": "Linux host resources from Telegraf (10s) and InfluxDB 1.x / InfluxQL. Counters use non-negative rates; missing values stay null.",
    "tags": ["skynet", "server", "telegraf", "influxdb"], "timezone": "browser",
    "schemaVersion": 39, "version": 1, "editable": False, "style": "dark",
    "refresh": "30s", "time": {"from": "now-30m", "to": "now"},
    "timepicker": {"refresh_intervals": ["10s", "30s", "1m", "5m"]},
    "annotations": {"list": []}, "links": [],
    "templating": {"list": [
        {"name": "DS_INFLUXDB", "label": "Datasource", "type": "datasource",
         "query": "influxdb", "regex": "/^InfluxDB-Telegraf$/", "refresh": 1,
         "current": {"text": "InfluxDB-Telegraf", "value": "skynet-influxdb-telegraf"}, "options": []},
        variable("host", "Host", "cpu", "host"),
        {"name": "interval", "label": "Interval", "type": "interval",
         "query": "10s,30s,1m,5m,15m,1h", "auto": True, "auto_min": "10s", "auto_count": 100,
         "current": {"text": "10s", "value": "10s"},
         "options": [{"text": v, "value": v, "selected": v == "10s"} for v in ("10s", "30s", "1m", "5m", "15m", "1h")]},
        variable("device", "Disk device", "disk", "device", HOST),
        variable("path", "Mount path", "disk", "path", HOST + ' AND "device" =~ /^${device:regex}$/'),
        variable("diskio_device", "I/O device", "diskio", "name", HOST),
        variable("interface", "Network interface", "net", "interface", HOST),
    ]},
    "panels": panels,
}

if __name__ == "__main__":
    path = ROOT / "projects/server-resources-overview.json"
    path.write_text(json.dumps(dashboard, ensure_ascii=False, indent=2) + "\n")
    print(f"Built {path.name}: {len(panels)} panels")
