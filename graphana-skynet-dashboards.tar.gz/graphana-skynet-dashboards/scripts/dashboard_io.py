"""Shared validation for Classic Grafana dashboard files (no external packages)."""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
UID_PATTERN = re.compile(r"[A-Za-z0-9_-]{1,40}")
VARIABLE = re.compile(r"\$(?:\{([A-Za-z_][A-Za-z0-9_]*)\}|([A-Za-z_][A-Za-z0-9_]*))$")


class DashboardError(ValueError):
    pass


def load_dashboard(path):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise DashboardError(f"{path}: cannot read JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise DashboardError(f"{path}: dashboard must be a JSON object")
    if "dashboard" in data:
        data = data["dashboard"]
    if not isinstance(data, dict) or "panels" not in data:
        raise DashboardError(f"{path}: export Classic JSON with panels; V2/resource models are not converted")
    return data


def walk(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def walk_panels(panels):
    if not isinstance(panels, list):
        raise DashboardError("panels must be an array")
    for panel in panels:
        if not isinstance(panel, dict):
            raise DashboardError("each panel must be an object")
        yield panel
        if "panels" in panel:
            yield from walk_panels(panel["panels"])


def validate_dashboard(data):
    if not isinstance(data.get("uid"), str) or not UID_PATTERN.fullmatch(data["uid"]):
        raise DashboardError("uid must contain 1–40 letters, digits, underscores or hyphens")
    if not isinstance(data.get("title"), str) or not data["title"].strip():
        raise DashboardError("title must be a non-empty string")
    if data.get("id") is not None:
        raise DashboardError("dashboard id must be null or omitted; use import_dashboard.py to normalize an export")
    if type(data.get("version", 0)) is not int or data.get("version", 0) < 0:
        raise DashboardError("version must be a non-negative integer")
    if data.get("__inputs"):
        raise DashboardError("unresolved __inputs: import via UI or supply --datasource INPUT_NAME=TARGET_UID")
    ids = set()
    for panel in walk_panels(data.get("panels")):
        pid = panel.get("id")
        if type(pid) is not int or pid < 0:
            raise DashboardError("panel id must be a non-negative integer")
        if pid in ids:
            raise DashboardError(f"duplicate panel id: {pid}")
        ids.add(pid)
        if not isinstance(panel.get("type"), str) or not panel["type"]:
            raise DashboardError(f"panel {pid}: missing type")
        # Row nesting, repeated panels and third-party panel types are allowed.
    templating = data.get("templating", {})
    if not isinstance(templating, dict) or not isinstance(templating.get("list", []), list):
        raise DashboardError("templating.list must be an array")
    variables = set()
    for variable in templating.get("list", []):
        if not isinstance(variable, dict) or not isinstance(variable.get("name"), str):
            raise DashboardError("each variable must have a name")
        if variable["name"] in variables:
            raise DashboardError(f"duplicate variable: {variable['name']}")
        variables.add(variable["name"])
    for node in walk(data):
        ds = node.get("datasource")
        ref = ds.get("uid") if isinstance(ds, dict) else ds
        if isinstance(ref, str):
            match = VARIABLE.fullmatch(ref)
            if match:
                name = match[1] or match[2]
                if name not in variables and not name.startswith("__"):
                    raise DashboardError(f"datasource variable {name} is not declared in templating.list")


def validate_collection(entries):
    uids, titles = {}, {}
    for path, data in entries:
        try:
            validate_dashboard(data)
        except DashboardError as exc:
            raise DashboardError(f"{path}: {exc}") from exc
        for key, registry in ((data["uid"], uids), (data["title"].strip().casefold(), titles)):
            if key in registry:
                raise DashboardError(f"{path}: conflicting UID or title with {registry[key]}")
            registry[key] = path


def project_dashboards(directory, exclude=None):
    for path in sorted(Path(directory).rglob("*.json")):
        if exclude is None or path.resolve() != Path(exclude).resolve():
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or "panels" not in data:
                raise DashboardError(f"{path}: expected unwrapped Classic JSON; use import_dashboard.py")
            yield path, data
