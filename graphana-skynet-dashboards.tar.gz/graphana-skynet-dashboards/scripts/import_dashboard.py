#!/usr/bin/env python3
"""Prepare a Classic export for provisioning, preserving panel IDs and queries."""
import argparse
import copy
import json
from pathlib import Path
import sys
import uuid

from dashboard_io import (
    ROOT, DashboardError, load_dashboard, project_dashboards,
    validate_collection, validate_dashboard, walk,
)


def parse_mappings(values):
    mappings = {}
    for value in values:
        key, sep, target = value.partition("=")
        if not sep or not key.strip() or not target.strip():
            raise DashboardError("use --datasource OLD_UID=NEW_UID or --datasource INPUT_NAME=NEW_UID")
        if key in mappings:
            raise DashboardError(f"duplicate datasource mapping: {key}")
        mappings[key] = target
    return mappings


def prepare_dashboard(original, mappings, uid=None, title=None):
    data = copy.deepcopy(original)
    substitutions = dict(mappings)
    for item in data.get("__inputs", []):
        if not isinstance(item, dict) or item.get("type") != "datasource":
            raise DashboardError("resolve non-datasource __inputs in Grafana UI, then export Classic JSON")
        name = item.get("name")
        if name not in mappings:
            raise DashboardError(f"missing --datasource {name}=TARGET_UID")
        substitutions[f"${{{name}}}"] = mappings[name]
        substitutions[f"${name}"] = mappings[name]
    for node in walk(data):
        ds = node.get("datasource")
        if isinstance(ds, str) and ds in substitutions:
            node["datasource"] = substitutions[ds]
        elif isinstance(ds, dict) and ds.get("uid") in substitutions:
            ds["uid"] = substitutions[ds["uid"]]
    for variable in data.get("templating", {}).get("list", []):
        if variable.get("type") == "datasource":
            current = variable.get("current", {})
            old = current.get("value")
            if isinstance(old, str) and old in substitutions:
                current.update(value=substitutions[old], text=substitutions[old])
                variable["options"] = []
                variable["refresh"] = 1
    data.pop("__inputs", None)
    data["id"] = None
    data["version"] = 1
    data["uid"] = uid or data.get("uid") or f"project-{uuid.uuid4().hex[:12]}"
    if title is not None:
        data["title"] = title
    validate_dashboard(data)
    return data


def save_dashboard(data, destination, directory, overwrite=False):
    directory = Path(directory).resolve()
    destination = Path(destination).resolve()
    if not destination.is_relative_to(directory) or destination.suffix != ".json":
        raise DashboardError("output must be a .json file inside projects/")
    if destination.exists() and not overwrite:
        raise DashboardError(f"{destination}: already exists; use --overwrite for an intentional update")
    entries = list(project_dashboards(directory, exclude=destination))
    validate_collection([*entries, (destination, data)])
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w" if overwrite else "x", encoding="utf-8") as output:
        output.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="Classic JSON export or API response with dashboard")
    parser.add_argument("--output", type=Path, help="destination under projects/; default projects/<uid>.json")
    parser.add_argument("--uid", help="override dashboard UID; panel IDs are preserved")
    parser.add_argument("--title", help="override dashboard title")
    parser.add_argument("--datasource", action="append", default=[], metavar="OLD=NEW_UID")
    parser.add_argument("--overwrite", action="store_true", help="allow updating the destination file")
    args = parser.parse_args()
    try:
        data = prepare_dashboard(load_dashboard(args.source), parse_mappings(args.datasource), args.uid, args.title)
        destination = args.output or ROOT / "projects" / f"{data['uid']}.json"
        save_dashboard(data, destination, ROOT / "projects", args.overwrite)
    except (DashboardError, OSError, ValueError, TypeError, AttributeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(f"Prepared {destination} (UID: {data['uid']}). Grafana loads it into Projects within 30 seconds when this directory is mounted.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
