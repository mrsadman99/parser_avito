# Добавление дашбордов проекта

Дашборд — определение визуализаций, запросов и переменных. Он не содержит
хранилище метрик, пароли datasource, плагины, правила маршрутизации сети
и содержимое внешних файлов. Эти зависимости подключаются отдельно.

## 1. Подключите datasource

В новой Grafana откройте **Connections → Data sources → Add data source**.
Выберите тот же тип и язык запросов, которые использует исходный дашборд.
Укажите URL, credentials и остальные параметры, затем выполните **Save & test**.
UID можно посмотреть в настройках/URL страницы datasource или получить через API.

Встроенный источник уже подготовлен:

| Имя | UID | Тип | Язык | База |
| --- | --- | --- | --- | --- |
| InfluxDB-Telegraf | skynet-influxdb-telegraf | InfluxDB | InfluxQL | telegraf |

Совпадение отображаемого имени не гарантирует совпадения UID между инстансами.
Запросы PromQL, LogQL, Flux, InfluxQL и SQL не преобразуются простой заменой UID.
Импортёр сохраняет запросы; сопоставляйте только совместимые datasource.

Если источник должен управляться через Git, добавьте отдельный YAML в
`provisioning/datasources/`. Пример структуры для внешнего Prometheus:

```yaml
apiVersion: 1
datasources:
  - name: Project Metrics
    uid: project-metrics
    type: prometheus
    access: proxy
    url: $PROJECT_METRICS_URL
    isDefault: false
    editable: false
```

Это шаблон, не описание существующего источника. Задайте его реальный URL
и передайте переменную **в контейнер Grafana**. Наличие переменной только в `.env`
не добавляет её в environment контейнера автоматически. Например, добавьте
к сервису `grafana` в Compose:

```yaml
environment:
  PROJECT_METRICS_URL: ${PROJECT_METRICS_URL:?Set the reachable backend URL}
```

Секреты задавайте через `secureJsonData` с переменными окружения. Не храните
credentials в JSON дашборда или YAML в Git. Глобальный `.env` описывает платформу;
дополнительные переменные вводятся только при подключении нового backend,
а не при добавлении каждого дашборда.

URL должен быть доступен **из контейнера Grafana**. `localhost` внутри него —
сам контейнер. Для backend в другом Compose можно использовать общую Docker-сеть
и сетевое имя сервиса; подключение этой сети настраивается в обоих Compose.
Для backend на хосте используйте доступный адрес хоста или host-gateway alias,
который явно добавлен в Compose. Вместе с источником перенесите настройки
аутентификации, TLS, derived fields, ссылки и внешние сервисы, если они нужны.
Не сохраняйте старые внутренние имена контейнеров, не доступные из новой сети.

Применение YAML datasource:

```bash
docker compose up -d
docker compose restart grafana
```

## 2. Экспортируйте исходный дашборд

В исходной Grafana откройте дашборд и меню экспорта, выберите **Classic JSON**.
Для прямого переноса можно экспортировать обычный JSON с исходными UID datasource.
Экспорт для внешнего использования часто создаёт `__inputs` и ссылки вида
`${DS_METRICS}` — их потребуется сопоставить при импорте.

Скачанный JSON с Grafana.com также можно использовать. Сохраните лицензию
и сведения об авторе внешнего дашборда. Library panels, дополнительные panel
plugins, alert rules и recording rules требуют отдельного переноса/установки.
Если возможно, преобразуйте library panels в обычные панели перед экспортом.

Скрипт поддерживает Classic JSON и ответ API вида `{"dashboard": {...}, "meta": {...}}`.
V2/resource JSON не преобразуется: экспортируйте Classic или импортируйте V2
через поддерживаемый UI, затем экспортируйте подходящую модель.

## 3. Выберите способ импорта

### Через Grafana UI

1. Откройте **Dashboards → New → Import**, загрузите JSON или укажите ID/URL
   из каталога Grafana.com.
2. Выберите папку **Projects**, название и UID. Если создаёте копию, UID должен
   отличаться от исходного. Не подтверждайте перезапись чужого дашборда.
3. Сопоставьте предложенные datasource. Для экспорта с жёсткими UID форма может
   не предложить выбор — обновите datasource панелей и переменных самостоятельно
   либо используйте скрипт ниже.
4. Проверьте панели, переменные, annotations, повторяемые строки, links и queries.
5. Если дашборд должен храниться в Git, экспортируйте настроенный Classic JSON
   и добавьте его в `projects/`. Сохранение через UI само по себе файл не создаёт.

UID дашборда, импортированного в UI, можно затем сохранить в Git: при загрузке
provider будет обновлять именно этот дашборд и управлять им из файлов.
После перехода на provisioning редактируйте источник в Git; UI-сохранение
отключено текущим provider.

### Через Git и provisioning

Из корня репозитория выполните команду, подставив свой экспорт и UID источников:

```bash
python3 scripts/import_dashboard.py /tmp/dashboard.json \
  --uid project-overview \
  --title "Project Overview" \
  --datasource old-influx-uid=skynet-influxdb-telegraf \
  --output projects/project-overview.json
```

Для external export с datasource input `DS_METRICS`:

```bash
python3 scripts/import_dashboard.py /tmp/dashboard.json \
  --uid project-overview \
  --datasource DS_METRICS=skynet-influxdb-telegraf
```

Если источников несколько, повторите `--datasource` для каждого. Формат слева —
точное старое значение datasource (UID или legacy имя) либо имя из `__inputs`;
справа — UID источника в новой Grafana. В частности, два inputs одного типа
можно направить в разные источники. Их нельзя объединять только по типу плагина.
Для `${DS_NAME}`, объявленного в `templating.list`, сохраните саму переменную,
исправьте её regex при несовпадающем имени datasource и при необходимости
сопоставьте UID в `current.value`.

Если UID datasource одинаков в обоих инстансах, аргумент `--datasource` не нужен.
Если не задан `--uid`, сохраняется UID из экспорта, а при его отсутствии создаётся
новый. Если не задан `--output`, файл записывается в `projects/<uid>.json`.

Импортёр:

- устанавливает dashboard `id: null`, `version: 1`;
- сохраняет ID панелей, queries, layout и остальные настройки;
- заменяет datasource в панелях, targets, annotations и query variables;
- обновляет выбранный UID у datasource variables;
- раскрывает datasource `__inputs`; inputs других типов требует сначала
  разрешить через UI;
- проверяет уникальность UID/названий среди JSON в `projects/`, включая подпапки;
- не перезаписывает существующий файл без `--overwrite`;
- сохраняет только внутрь `projects/`.

Он не обращается к Grafana API и не проверяет существование datasource или
установку плагинов на сервере. Перед первым импортом проверьте UID в Grafana:
совпадение с существующим дашбордом приведёт к его обновлению provisioning.

После подготовки:

```bash
make check
git add projects/
git commit -m "Add project dashboard"
git push origin main
```

На сервере:

```bash
git pull --ff-only origin main
make check
docker compose up -d
```

При работающей Grafana JSON перечитываются каждые 30s. Для нового дашборда
не нужны новая строка в `.env`, отдельный provider или изменение Compose.

Краткий эквивалент команды: `make import-dashboard ARGS='/tmp/dashboard.json --uid project-overview'`.
Для путей/названий с пробелами удобнее вызывать Python напрямую с обычным shell quoting.

## 4. Обновляйте без изменения идентичности

```bash
python3 scripts/import_dashboard.py /tmp/updated-dashboard.json \
  --uid project-overview \
  --output projects/project-overview.json \
  --overwrite
make check
```

Сохраняйте UID для обновления того же дашборда. `--overwrite` разрешает замену
только указанного файла и не отключает проверку конфликтов с другими файлами.
Существующие файлы проверяются до записи. Повторяйте нужные datasource mappings,
если новый экспорт всё ещё содержит старые ссылки или `__inputs`.

`make check` проверяет JSON, уникальность идентификаторов и переменные datasource.
Валидатор допускает другие типы панелей и datasource; корректность их запросов
и наличие плагинов проверяются в самой Grafana. Ограничение репозитория —
Classic JSON с явными уникальными числовыми ID панелей.

## 5. Проверка в Grafana

- **Connections → Data sources → Save & test**: источник доступен.
- **Dashboards → Projects**: нужный дашборд появился.
- Выберите актуальный период, затем отдельный host и All, если эти переменные есть.
- **Inspect → Query**: нет старых UID, нераскрытых `${DS_*}` и ошибок запроса.
- Убедитесь, что название measurement/метрики, поля, теги и язык запросов
  соответствуют backend. Проверяйте их в Explore.
- Проверьте annotations, dashboard links, data links и внешние файлы отдельно.

Если JSON удалён, дашборд может остаться в базе: provider настроен с
`disableDeletion: true`. Если JSON изменён, но не обновился, проверьте mount
`projects` и `docker compose logs --tail=100 grafana`.

Источники: [импорт Grafana](https://grafana.com/docs/grafana/latest/visualizations/dashboards/build-dashboards/import-dashboards/),
[file provisioning](https://grafana.com/docs/grafana/latest/administration/provisioning/).
