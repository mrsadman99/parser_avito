# Каталог панелей

Сгенерировано из поставляемых JSON. Для stat легенда отображается как имя значения; для timeseries — в таблице под графиком. `null` в thresholds обозначает базовую ступень.

## Server Resources Overview

| ID | Panel | Type | Unit | Thresholds |
| --- | --- | --- | --- | --- |
| 1 | CPU % | stat | percent | green: None, yellow: 80, red: 90 |
| 2 | RAM % | stat | percent | green: None, yellow: 80, red: 90 |
| 3 | Disk % by mount | stat | percent | green: None, yellow: 80, red: 90 |
| 4 | Load Average (1m) | stat | short | green: None |
| 5 | Uptime | stat | s | green: None |
| 6 | CPU total utilization | timeseries | percent | green: None, yellow: 80, red: 90 |
| 7 | CPU utilization by core | timeseries | percent | green: None, yellow: 80, red: 90 |
| 8 | CPU modes | timeseries | percent | green: None, yellow: 80, red: 90 |
| 9 | CPU I/O wait | timeseries | percent | green: None, yellow: 80, red: 90 |
| 10 | Memory capacity | timeseries | bytes | green: None |
| 11 | Memory utilization | timeseries | percent | green: None, yellow: 80, red: 90 |
| 12 | Swap capacity | timeseries | bytes | green: None |
| 13 | Swap utilization | timeseries | percent | green: None, yellow: 80, red: 90 |
| 14 | Disk capacity by mount | timeseries | bytes | green: None |
| 15 | Disk utilization by mount | timeseries | percent | green: None, yellow: 80, red: 90 |
| 16 | Inodes by mount | timeseries | short | green: None |
| 17 | Inode utilization by mount | timeseries | percent | green: None, yellow: 80, red: 90 |
| 18 | Disk I/O throughput | timeseries | Bps | green: None |
| 19 | Disk I/O accumulated time rate | timeseries | suffix:ms/s | green: None |
| 20 | Network traffic | timeseries | Bps | green: None |
| 21 | Network packets | timeseries | pps | green: None |
| 22 | Network errors | timeseries | suffix:errors/s | green: None, red: 1 |
| 23 | Network drops | timeseries | suffix:drops/s | green: None, red: 1 |
| 24 | Processes | timeseries | short | green: None |
| 25 | Blocked and zombie processes | timeseries | short | green: None, red: 1 |
| 26 | Load averages | timeseries | short | green: None |
| 27 | Logged-in users | timeseries | short | green: None |

### 1. CPU %

Last non-null bucket in the selected time range, separately for each series. Check time range and collector freshness if the host stops reporting.

Target A; legend: `[[tag_host]] [[tag_cpu]] · busy`.

```sql
SELECT 100 - mean("usage_idle") AS "busy" FROM "cpu" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "cpu" = 'cpu-total' GROUP BY time($interval), "host", "cpu" fill(null)
```

### 2. RAM %

Last non-null bucket in the selected time range, separately for each series. Check time range and collector freshness if the host stops reporting.

Target A; legend: `[[tag_host]] · used`.

```sql
SELECT mean("used_percent") AS "used" FROM "mem" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 3. Disk % by mount

Last non-null bucket in the selected time range, separately for each series. Check time range and collector freshness if the host stops reporting.

Target A; legend: `[[tag_host]] [[tag_device]] [[tag_path]] · used`.

```sql
SELECT mean("used_percent") AS "used" FROM "disk" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/ GROUP BY time($interval), "host", "device", "path" fill(null)
```

### 4. Load Average (1m)

Last non-null bucket in the selected time range, separately for each series. Check time range and collector freshness if the host stops reporting.

Target A; legend: `[[tag_host]] · load1`.

```sql
SELECT mean("load1") AS "load1" FROM "system" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 5. Uptime

Last non-null bucket in the selected time range, separately for each series. Check time range and collector freshness if the host stops reporting.

Target A; legend: `[[tag_host]] · uptime`.

```sql
SELECT last("uptime") AS "uptime" FROM "system" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 6. CPU total utilization

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_cpu]] · busy`.

```sql
SELECT 100 - mean("usage_idle") AS "busy" FROM "cpu" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "cpu" = 'cpu-total' GROUP BY time($interval), "host", "cpu" fill(null)
```

### 7. CPU utilization by core

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_cpu]] · busy`.

```sql
SELECT 100 - mean("usage_idle") AS "busy" FROM "cpu" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "cpu" != 'cpu-total' GROUP BY time($interval), "host", "cpu" fill(null)
```

### 8. CPU modes

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_cpu]] · user`.

```sql
SELECT mean("usage_user") AS "user" FROM "cpu" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "cpu" = 'cpu-total' GROUP BY time($interval), "host", "cpu" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_cpu]] · system`.

```sql
SELECT mean("usage_system") AS "system" FROM "cpu" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "cpu" = 'cpu-total' GROUP BY time($interval), "host", "cpu" fill(null)
```

Target C; legend: `[[tag_host]] [[tag_cpu]] · idle`.

```sql
SELECT mean("usage_idle") AS "idle" FROM "cpu" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "cpu" = 'cpu-total' GROUP BY time($interval), "host", "cpu" fill(null)
```

### 9. CPU I/O wait

Percentage of CPU time waiting for I/O; the generic 80/90 thresholds may need lower values for your workload.

Target A; legend: `[[tag_host]] [[tag_cpu]] · iowait`.

```sql
SELECT mean("usage_iowait") AS "iowait" FROM "cpu" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "cpu" = 'cpu-total' GROUP BY time($interval), "host", "cpu" fill(null)
```

### 10. Memory capacity

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] · used`.

```sql
SELECT mean("used") AS "used" FROM "mem" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target B; legend: `[[tag_host]] · available`.

```sql
SELECT mean("available") AS "available" FROM "mem" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target C; legend: `[[tag_host]] · total`.

```sql
SELECT mean("total") AS "total" FROM "mem" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 11. Memory utilization

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] · used`.

```sql
SELECT mean("used_percent") AS "used" FROM "mem" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 12. Swap capacity

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] · used`.

```sql
SELECT mean("used") AS "used" FROM "swap" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target B; legend: `[[tag_host]] · free`.

```sql
SELECT mean("free") AS "free" FROM "swap" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target C; legend: `[[tag_host]] · total`.

```sql
SELECT mean("total") AS "total" FROM "swap" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 13. Swap utilization

Hosts without swap may report zero or no series. Missing data is not filled with zero.

Target A; legend: `[[tag_host]] · used`.

```sql
SELECT mean("used_percent") AS "used" FROM "swap" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 14. Disk capacity by mount

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_device]] [[tag_path]] · used`.

```sql
SELECT mean("used") AS "used" FROM "disk" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/ GROUP BY time($interval), "host", "device", "path" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_device]] [[tag_path]] · free`.

```sql
SELECT mean("free") AS "free" FROM "disk" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/ GROUP BY time($interval), "host", "device", "path" fill(null)
```

Target C; legend: `[[tag_host]] [[tag_device]] [[tag_path]] · total`.

```sql
SELECT mean("total") AS "total" FROM "disk" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/ GROUP BY time($interval), "host", "device", "path" fill(null)
```

### 15. Disk utilization by mount

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_device]] [[tag_path]] · used`.

```sql
SELECT mean("used_percent") AS "used" FROM "disk" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/ GROUP BY time($interval), "host", "device", "path" fill(null)
```

### 16. Inodes by mount

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_device]] [[tag_path]] · inodes_used`.

```sql
SELECT mean("inodes_used") AS "inodes_used" FROM "disk" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/ GROUP BY time($interval), "host", "device", "path" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_device]] [[tag_path]] · inodes_free`.

```sql
SELECT mean("inodes_free") AS "inodes_free" FROM "disk" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/ GROUP BY time($interval), "host", "device", "path" fill(null)
```

### 17. Inode utilization by mount

Used / (used + free). Filesystems reporting no inodes are excluded to avoid division by zero.

Target A; legend: `[[tag_host]] [[tag_device]] [[tag_path]] · used`.

```sql
SELECT 100 * mean("inodes_used") / (mean("inodes_used") + mean("inodes_free")) AS "used" FROM "disk" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "device" =~ /^${device:regex}$/ AND "path" =~ /^${path:regex}$/ AND ("inodes_used" > 0 OR "inodes_free" > 0) GROUP BY time($interval), "host", "device", "path" fill(null)
```

### 18. Disk I/O throughput

Non-negative rate of cumulative bytes, grouped by host and device. Counter resets create gaps; the first bucket needs a preceding sample.

Target A; legend: `[[tag_host]] [[tag_name]] · read`.

```sql
SELECT non_negative_derivative(last("read_bytes"), 1s) AS "read" FROM "diskio" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "name" =~ /^${diskio_device:regex}$/ GROUP BY time($interval), "host", "name" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_name]] · write`.

```sql
SELECT non_negative_derivative(last("write_bytes"), 1s) AS "write" FROM "diskio" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "name" =~ /^${diskio_device:regex}$/ GROUP BY time($interval), "host", "name" fill(null)
```

### 19. Disk I/O accumulated time rate

Rate of cumulative read_time/write_time (milliseconds per second). This is NOT latency per operation or disk utilization; concurrent requests may exceed 1000 ms/s. Operation counters are not in the supplied schema.

Target A; legend: `[[tag_host]] [[tag_name]] · read`.

```sql
SELECT non_negative_derivative(last("read_time"), 1s) AS "read" FROM "diskio" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "name" =~ /^${diskio_device:regex}$/ GROUP BY time($interval), "host", "name" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_name]] · write`.

```sql
SELECT non_negative_derivative(last("write_time"), 1s) AS "write" FROM "diskio" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "name" =~ /^${diskio_device:regex}$/ GROUP BY time($interval), "host", "name" fill(null)
```

### 20. Network traffic

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_interface]] · receive`.

```sql
SELECT non_negative_derivative(last("bytes_recv"), 1s) AS "receive" FROM "net" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "interface" =~ /^${interface:regex}$/ GROUP BY time($interval), "host", "interface" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_interface]] · send`.

```sql
SELECT non_negative_derivative(last("bytes_sent"), 1s) AS "send" FROM "net" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "interface" =~ /^${interface:regex}$/ GROUP BY time($interval), "host", "interface" fill(null)
```

### 21. Network packets

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_interface]] · receive`.

```sql
SELECT non_negative_derivative(last("packets_recv"), 1s) AS "receive" FROM "net" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "interface" =~ /^${interface:regex}$/ GROUP BY time($interval), "host", "interface" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_interface]] · send`.

```sql
SELECT non_negative_derivative(last("packets_sent"), 1s) AS "send" FROM "net" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "interface" =~ /^${interface:regex}$/ GROUP BY time($interval), "host", "interface" fill(null)
```

### 22. Network errors

Counter rate; red at >= 1 error/s. Smaller positive rates are still worth investigating.

Target A; legend: `[[tag_host]] [[tag_interface]] · in`.

```sql
SELECT non_negative_derivative(last("err_in"), 1s) AS "in" FROM "net" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "interface" =~ /^${interface:regex}$/ GROUP BY time($interval), "host", "interface" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_interface]] · out`.

```sql
SELECT non_negative_derivative(last("err_out"), 1s) AS "out" FROM "net" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "interface" =~ /^${interface:regex}$/ GROUP BY time($interval), "host", "interface" fill(null)
```

### 23. Network drops

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] [[tag_interface]] · in`.

```sql
SELECT non_negative_derivative(last("drop_in"), 1s) AS "in" FROM "net" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "interface" =~ /^${interface:regex}$/ GROUP BY time($interval), "host", "interface" fill(null)
```

Target B; legend: `[[tag_host]] [[tag_interface]] · out`.

```sql
SELECT non_negative_derivative(last("drop_out"), 1s) AS "out" FROM "net" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ AND "interface" =~ /^${interface:regex}$/ GROUP BY time($interval), "host", "interface" fill(null)
```

### 24. Processes

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] · total`.

```sql
SELECT mean("total") AS "total" FROM "processes" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target B; legend: `[[tag_host]] · running`.

```sql
SELECT mean("running") AS "running" FROM "processes" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target C; legend: `[[tag_host]] · sleeping`.

```sql
SELECT mean("sleeping") AS "sleeping" FROM "processes" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 25. Blocked and zombie processes

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] · blocked`.

```sql
SELECT mean("blocked") AS "blocked" FROM "processes" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target B; legend: `[[tag_host]] · zombies`.

```sql
SELECT mean("zombies") AS "zombies" FROM "processes" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 26. Load averages

Runnable/uninterruptible tasks, not a percentage. Compare with logical CPU count; no universal absolute threshold is applied.

Target A; legend: `[[tag_host]] · load1`.

```sql
SELECT mean("load1") AS "load1" FROM "system" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target B; legend: `[[tag_host]] · load5`.

```sql
SELECT mean("load5") AS "load5" FROM "system" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

Target C; legend: `[[tag_host]] · load15`.

```sql
SELECT mean("load15") AS "load15" FROM "system" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```

### 27. Logged-in users

Запрос и представление из JSON.

Target A; legend: `[[tag_host]] · users`.

```sql
SELECT mean("n_users") AS "users" FROM "system" WHERE $timeFilter AND "host" =~ /^${host:regex}$/ GROUP BY time($interval), "host" fill(null)
```
