# Проверки конфигурации

Для локальной проверки требуются Python 3.11+ и Docker Compose CLI:

```bash
make test
make check
```

`make test` проверяет импорт Classic/API JSON, вложенные панели, замену нескольких
источников данных в панелях/targets/annotations/variables, сохранение запросов
и ID панелей, обработку `__inputs`, конфликты UID/названий, защиту от случайной
перезаписи и записи за пределами `projects/`.

Семантика встроенного серверного дашборда проверяется отдельным тестом:
схема measurements/fields/tags, группировки, interval, rates и Telegraf TOML.
Эти ограничения не применяются к другим импортированным дашбордам.

`make check` проверяет произвольное количество JSON в `projects/` и подпапках,
а затем выполняет `docker compose config --quiet` с текущим `.env`.
Он не ограничивает тип datasource, язык запросов или набор panel plugins.

## Результат подготовки

- 11 автоматических тестов прошли.
- Универсальная проверка JSON и Telegraf TOML прошла.
- Compose нормализуется: Grafana, InfluxDB и Telegraf, два volumes.
- Запуск импортёра как CLI проверен на временном JSON, включая подпапку
  и отказ от перезаписи без `--overwrite`.
- Текущий `.env` содержит только параметры платформы, исключён из Git,
  права доступа 0600. Реальные секреты не включены в архивы или документацию.

## Проверка на целевом Linux

```bash
make check-runtime
make up
docker compose ps
docker compose logs --tail=100 grafana influxdb telegraf
```

При подготовке локальный Docker daemon недоступен, поэтому контейнерные
проверки, реальное выполнение запросов и отображение в Grafana не выполнялись.
Офлайн-проверка не подтверждает доступность datasource, установку panel plugins,
корректность всех языков запросов, работоспособность data links и сети.

После запуска выполните проверки из [IMPORTING.md](IMPORTING.md): Save & test,
Explore, Inspect → Query, переменные и ссылки. Ни `make check`, ни импортёр
не обращаются к Grafana API и не проверяют конфликты с дашбордами вне Git.
