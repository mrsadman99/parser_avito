# graphana-skynet-dashboards

Универсальный репозиторий дашбордов проектов с Grafana в Docker.
Любой подготовленный Classic JSON из `projects/` автоматически загружается
в папку **Projects**. Добавление дашборда не требует изменения `.env` или Compose.

Базовый стек: Grafana 13.2.2, InfluxDB 1.12.4 и Telegraf 1.38.4 для Linux.
В комплекте есть **Server Resources Overview**: 27 панелей, английский интерфейс,
последние 30 минут, обновление 30s, datasource `InfluxDB-Telegraf`.
Другие источники данных подключаются независимо, через Grafana UI или provisioning.

## Структура

```text
graphana-skynet-dashboards/
├── .env.example                         # Только настройки платформы, без секретов
├── .gitignore                           # .env, резервные копии и runtime data
├── .github/CODEOWNERS                    # Владелец репозитория
├── docker-compose.yml                   # Grafana + InfluxDB + Telegraf
├── Makefile                             # Запуск, импорт, проверки
├── README.md                            # Настройка платформы и работа с Git
├── LICENSE
├── THIRD_PARTY_NOTICES.md
├── projects/                            # Все активные дашборды, включая подпапки
│   └── server-resources-overview.json
├── provisioning/
│   ├── dashboards/default.yaml          # projects/ → Projects
│   └── datasources/datasource.yaml       # Базовый InfluxDB datasource
├── monitoring/
│   ├── influxdb/retention.iql            # telegraf, retention policy 30 дней
│   └── telegraf/telegraf.conf            # Метрики Linux каждые 10s
├── scripts/
│   ├── init_env.py                      # Создание .env с правами 0600
│   ├── import_dashboard.py              # Импорт Classic JSON в projects/
│   ├── dashboard_io.py                  # Общая обработка и валидация JSON
│   ├── validate.py                      # Проверка всех дашбордов
│   └── build_dashboard.py               # Генератор встроенного server dashboard
├── tests/                               # Тесты импортёра и серверных запросов
├── licenses/provenance.json             # Исторические сведения о происхождении
└── docs/
    ├── IMPORTING.md                     # Импорт через UI и Git, datasource mapping
    ├── PANELS.md                        # Запросы и параметры серверных панелей
    └── VALIDATION.md                    # Проверки и их ограничения
```

`projects/*.json` и `projects/<любая-подпапка>/*.json` попадают в одну папку
Grafana **Projects**. Подпапки помогают организовать файлы в Git, но не создают
вложенные папки Grafana при текущем provider. Имена файлов произвольны; UID
дашбордов и названия внутри Projects должны быть уникальными.

## Запуск

Требуются native Linux, Docker Engine с Compose v2+ и Python 3.11+.
Команды выполняются из корня этого репозитория.

```bash
make init
```

Откройте `.env` и настройте:

| Переменная | Назначение |
| --- | --- |
| `TELEGRAF_HOST` | Стабильный уникальный тег хоста для метрик; задайте на целевом сервере |
| `GRAFANA_BIND_ADDRESS`, `GRAFANA_PORT` | Адрес и порт Grafana на Docker-хосте |
| `GRAFANA_ROOT_URL` | Адрес Grafana для браузера с завершающим `/` |
| `GRAFANA_ADMIN_USER`, `GRAFANA_ADMIN_PASSWORD` | Администратор при первом запуске |
| `INFLUXDB_HOST_PORT` | Loopback-порт для Telegraf, по умолчанию 18086 |
| `INFLUXDB_ADMIN_PASSWORD` | Пароль администратора новой InfluxDB |
| `INFLUXDB_READ_PASSWORD`, `INFLUXDB_WRITE_PASSWORD` | Отдельные пароли Grafana и Telegraf |
| `GRAFANA_VOLUME`, `INFLUXDB_VOLUME` | Имена постоянных Docker volumes |

`make init` генерирует четыре пароля и не перезаписывает существующий `.env`.
Файл исключён из Git. Списки дашбордов, пути к логам отдельных приложений
и настройки их сборщиков в базовом `.env` не нужны.

По умолчанию пример конфигурации открывает Grafana на `http://localhost:3001/`.
При использовании reverse proxy задайте его внешний URL в `GRAFANA_ROOT_URL`,
а upstream направьте на фактический `GRAFANA_BIND_ADDRESS:GRAFANA_PORT`.
Для прямого доступа из сети задайте адрес привязки и внешний порт явно.
Сам reverse proxy в Compose не входит.

```bash
make check
docker compose pull
make check-runtime
make up
docker compose ps
```

После запуска откройте `GRAFANA_ROOT_URL`. В **Dashboards → Projects** появятся
JSON из репозитория. В **Connections → Data sources** создастся InfluxDB-Telegraf.
Глобальная тема по умолчанию — Dark; пользовательская Preferences имеет приоритет.

Telegraf использует host network/PID и read-only mount корня Linux-хоста.
Он запускается напрямую через `/usr/bin/telegraf` от UID 0 с `cap_drop: [ALL]`
и `no-new-privileges`. Стандартный entrypoint образа вызывает `setcap` и
`setpriv`, поэтому несовместим с этими ограничениями. При переопределённом
entrypoint передавайте в `docker compose run` только аргументы Telegraf,
например `docker compose run --rm --no-deps telegraf --config /etc/telegraf/telegraf.conf --test`.
Он не требует Docker socket и `privileged: true`. В Docker Desktop измеряется
Linux VM, а не физический хост macOS/Windows. На системах с rootless Docker,
SELinux или user namespace remapping проверьте доступ к host-метрикам отдельно.

Если контейнер сообщает `Failed to set additional capabilities` или
`setpriv: setresuid failed`, проверьте наличие `entrypoint: ["/usr/bin/telegraf"]`
в сервисе Telegraf и пересоздайте его после обновления Compose:

```bash
docker compose up -d --force-recreate telegraf
docker compose logs --tail=100 telegraf
```

Один `restart` не меняет entrypoint уже созданного контейнера.

## Добавление существующего дашборда

Полная инструкция: **[docs/IMPORTING.md](docs/IMPORTING.md)**.

1. Создайте или подключите datasource нужного типа в новой Grafana, выполните
   Save & test и узнайте его UID. Дашборд не переносит сервер метрик и его данные.
2. Экспортируйте исходный дашборд в Classic JSON либо загрузите JSON из каталога.
3. Подготовьте файл командой импорта. Пример ниже иллюстративный: замените имя
   входного файла и старый UID на значения вашего экспорта.

   ```bash
   python3 scripts/import_dashboard.py /tmp/dashboard.json \
     --uid project-overview \
     --title "Project Overview" \
     --datasource old-influx-uid=skynet-influxdb-telegraf \
     --output projects/project-overview.json
   make check
   ```

   Это сопоставление подходит только для совместимого InfluxDB datasource.
   Для Prometheus, Loki, SQL и других источников укажите UID соответствующего типа.
4. При работающем Compose дашборд загрузится в Projects в течение 30 секунд.
   Если импорт выполнялся на рабочем компьютере, сначала отправьте JSON в Git
   и выполните `git pull --ff-only` на сервере.
5. Проверьте переменные и запросы в Grafana, затем сохраните файл в Git.

Можно сначала использовать **Dashboards → New → Import** в UI, проверить
дашборд, экспортировать его обратно в Classic JSON и добавить в `projects/`.
Прямой UI-импорт сохраняется в базе Grafana, но не создаёт файл в Git.

## Обновления и удаление

```bash
git pull --ff-only origin main
make check
docker compose up -d
```

Grafana сканирует `projects/` каждые 30s. После изменения только JSON
перезапуск не нужен. После изменения provider или datasource YAML выполните
`docker compose restart grafana`; после изменения Telegraf-конфига —
`docker compose restart telegraf`. Изменения `.env` применяйте через
`docker compose up -d`: один `restart` не перечитывает окружение.

Provisioned dashboards нельзя сохранять через UI (`allowUiUpdates: false`).
Для постоянного изменения обновите JSON в Git или повторите импорт с теми же
UID и файлом, добавив `--overwrite`. Уникальность UID проверяется только
по файлам этого репозитория: перед первым подключением проверьте конфликты
с дашбордами, уже находящимися в целевой Grafana.

`disableDeletion: true` сохраняет дашборд в базе при удалении его JSON.
Это не команда удаления: для очистки базы используйте администрирование Grafana
или осознанно измените политику provider. Не подключайте один UID через несколько
providers или одновременно через Git Sync и file provisioning.

При переименовании JSON сохраняйте UID, если требуется обновление того же
дашборда. При создании копии задайте новый UID и новое название.

## Переход с другой конфигурации Grafana

Конфигурация по умолчанию использует нейтральный volume
`graphana-skynet-dashboards_grafana-data`. Смена имени volume подключает новую
пустую базу Grafana: пользователи, UI-дашборды и datasource из прежнего тома
автоматически не копируются. Старые volumes не удаляются командами проекта.

Для чистого инстанса оставьте новое имя и импортируйте нужные дашборды по
[инструкции](docs/IMPORTING.md). Если требуется сохранить **весь** инстанс:

1. Найдите реальный volume работающего контейнера:

   ```bash
   docker ps --format '{{.Names}}\t{{.Image}}'
   read -r -p 'Current Grafana container name: ' grafana_container
   docker inspect --format '{{range .Mounts}}{{println .Destination .Name .Source}}{{end}}' "$grafana_container"
   ```

2. Остановите только старую Grafana, сохраните её volume и резервную копию.
   Не останавливайте нужные другим проектам сборщики и хранилища данных.
3. Либо задайте точное имя существующего тома в `GRAFANA_VOLUME`, либо скопируйте
   его содержимое в новый нейтральный volume. Пример копирования для bash:

   ```bash
   set -e
   read -r -p 'Stopped Grafana source volume: ' source_volume
   read -r -p 'New empty destination volume: ' destination_volume
   test -n "$source_volume"
   test -n "$destination_volume"
   test "$source_volume" != "$destination_volume"
   docker volume inspect "$source_volume"
   docker volume create "$destination_volume"
   docker run --rm \
     --mount "type=volume,src=$source_volume,dst=/source,readonly" \
     --mount "type=volume,src=$destination_volume,dst=/destination" \
     alpine:3.22 sh -ec 'test -z "$(ls -A /destination)"; cp -a /source/. /destination/'
   ```

   Копируйте только из остановленной Grafana; скрипт отказывается писать в
   непустое назначение. Перед копированием сделайте резервную копию источника.
4. Укажите выбранный том в `.env`. Проверьте свободный порт, прежние datasource
   и URL из контейнера новой Grafana. Пароль администратора из существующей базы
   имеет приоритет над начальным паролем в `.env`.
5. Запустите новый Compose. Не запускайте две Grafana на одной SQLite-базе.

Удалённые из Compose сервисы не останавливаются автоматически обычным `up -d`.
При обновлении старого развёртывания сначала проверьте `docker compose ps -a`.
Не применяйте `--remove-orphans`, пока не выясните, не обслуживают ли эти сервисы
источники данных ваших дашбордов. Старые provisioned dashboards и datasource
тоже могут остаться в базе — их наличие не означает, что backend доступен.

## Метрики сервера

InfluxDB: база `telegraf`, default retention policy `telegraf`, хранение 30 дней.
Telegraf собирает CPU, mem, swap, disk, diskio, net, system, processes каждые 10s.
Grafana получает READ, Telegraf — WRITE; администратор не используется для панелей.
Инициализация паролей и RP выполняется только при пустом InfluxDB volume.
Смена значений в `.env` не меняет пароли уже созданных пользователей InfluxDB.

Серверный дашборд использует `${DS_INFLUXDB}`, multi-select `host` с All,
`interval` с минимумом 10s, фильтры дисков, mount paths и интерфейсов.
Хосты не усредняются между собой. CPU/RAM/swap/disk/inode: жёлтый >=80%, красный
>=90%. Это визуальные thresholds, не alert rules.

Disk/network counters преобразуются в non-negative rates. Нули не подставляются
в пропуски. Накопленное время Disk I/O показано в ms/s, не latency на операцию;
для latency нужны дополнительные счётчики операций. Stat показывает последний
непустой bucket выбранного периода, а не отдельный признак доступности хоста.
Подробные запросы, единицы и легенды — в [docs/PANELS.md](docs/PANELS.md).

После запуска подождите 30–60 секунд, проверьте datasource через Save & test,
затем в Explore / InfluxDB-Telegraf выполните:

```sql
SHOW MEASUREMENTS
SHOW TAG VALUES FROM "cpu" WITH KEY = "host"
SELECT last("usage_idle") FROM "cpu" WHERE time > now() - 2m AND "cpu" = 'cpu-total' GROUP BY "host"
```

Сопоставьте показатели с `uptime`, `free -b`, `df -h`, `df -i`, `ip -s link`
на целевом сервере. В Inspect → Query проверьте подстановку переменных.

```bash
make test
make check
docker compose logs --tail=100 grafana influxdb telegraf
```

Проверки и ограничения описаны в [docs/VALIDATION.md](docs/VALIDATION.md).
Генератор `scripts/build_dashboard.py` относится только к встроенному server
dashboard; для других JSON его запускать не требуется.

## GitHub

Целевой репозиторий: `mrsadman99/graphana-skynet-dashboards`, private, ветка main.
Если remote ещё не создан, используйте авторизованный GitHub CLI:

```bash
gh auth login
gh repo create mrsadman99/graphana-skynet-dashboards --private
git remote get-url origin || git remote add origin git@github.com:mrsadman99/graphana-skynet-dashboards.git
git push -u origin main
gh repo edit mrsadman99/graphana-skynet-dashboards --default-branch main
```

При работе из архива без `.git` сначала выполните `git init -b main`,
`git add .`, `git commit`. Если remote уже существует, пропустите его создание.
Наличие URL origin не подтверждает публикацию. CI/CD и Git Sync не настроены:
обновления доставляются обычным Git, а Grafana читает локальные файлы.

## Документация Grafana

- [File provisioning](https://grafana.com/docs/grafana/latest/administration/provisioning/)
- [Импорт дашбордов](https://grafana.com/docs/grafana/latest/visualizations/dashboards/build-dashboards/import-dashboards/)
- [Настройка InfluxDB](https://grafana.com/docs/grafana/latest/datasources/influxdb/configure/)
