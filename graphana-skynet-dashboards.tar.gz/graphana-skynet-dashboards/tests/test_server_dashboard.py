import json
from pathlib import Path
import re
import tomllib
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = {
    "cpu": ({"usage_user", "usage_system", "usage_idle", "usage_iowait"}, {"host", "cpu"}),
    "mem": ({"used", "available", "total", "used_percent"}, {"host"}),
    "swap": ({"used", "free", "total", "used_percent"}, {"host"}),
    "disk": ({"used", "free", "total", "used_percent", "inodes_used", "inodes_free"}, {"host", "device", "path"}),
    "diskio": ({"read_bytes", "write_bytes", "read_time", "write_time"}, {"host", "name"}),
    "net": ({"bytes_sent", "bytes_recv", "packets_sent", "packets_recv", "err_in", "err_out", "drop_in", "drop_out"}, {"host", "interface"}),
    "system": ({"load1", "load5", "load15", "n_users", "uptime"}, {"host"}),
    "processes": ({"total", "running", "sleeping", "blocked", "zombies"}, {"host"}),
}


class ServerDashboardTests(unittest.TestCase):
    def test_metric_queries_and_telegraf_contract(self):
        server = json.loads((ROOT / "projects/server-resources-overview.json").read_text())
        assert server["time"] == {"from": "now-30m", "to": "now"}
        assert server["refresh"] == "30s"
        variables = {v["name"]: v for v in server["templating"]["list"]}
        for name in ("host", "device", "path", "diskio_device", "interface"):
            assert variables[name]["multi"] and variables[name]["includeAll"]
            assert variables[name]["allValue"] == ".*"
        assert variables["interval"]["auto_min"] == "10s"
        fields_seen = {m: set() for m in SCHEMA}
        for p in server["panels"]:
            assert p["datasource"] == {"type": "influxdb", "uid": "${DS_INFLUXDB}"}
            assert p["fieldConfig"]["defaults"]["unit"]
            assert p["fieldConfig"]["defaults"]["thresholds"]["steps"][0]["value"] is None
            for t in p["targets"]:
                q = t["query"]
                assert t["datasource"] == p["datasource"]
                assert t["rawQuery"] and t["resultFormat"] == "time_series"
                assert '$timeFilter' in q and 'time($interval)' in q and 'fill(null)' in q
                assert '"host" =~ /^${host:regex}$/' in q
                measurement = re.search(r'FROM "(\w+)"', q)[1]
                allowed_fields, allowed_tags = SCHEMA[measurement]
                fields = set(re.findall(r'(?:mean|last)\("(\w+)"\)', q))
                assert fields <= allowed_fields, (measurement, fields)
                fields_seen[measurement].update(fields)
                tags = set(re.findall(r'"(\w+)"', q.split('GROUP BY', 1)[1]))
                assert "host" in tags and tags <= allowed_tags
                assert set(re.findall(r'\[\[tag_(\w+)\]\]', t["alias"])) == tags
                if measurement in {"net", "diskio"}:
                    assert 'non_negative_derivative(last(' in q and ', 1s)' in q
                for v in re.findall(r'\$\{(\w+)(?::\w+)?\}', q):
                    assert v in variables
        for measurement, (fields, _) in SCHEMA.items():
            assert fields_seen[measurement] == fields, (measurement, fields - fields_seen[measurement])
        config = tomllib.loads((ROOT / "monitoring/telegraf/telegraf.conf").read_text())
        assert set(config["inputs"]) == set(SCHEMA)
        assert config["agent"]["interval"] == "10s"
        assert config["outputs"]["influxdb"][0]["retention_policy"] == "telegraf"
