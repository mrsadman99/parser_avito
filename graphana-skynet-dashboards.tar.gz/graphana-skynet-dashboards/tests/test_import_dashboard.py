import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from dashboard_io import DashboardError, load_dashboard, project_dashboards, validate_collection
from import_dashboard import parse_mappings, prepare_dashboard, save_dashboard


def dashboard(uid="example", title="Example"):
    return {"id": 12, "uid": uid, "title": title, "version": 8,
            "templating": {"list": []}, "panels": [
                {"id": 1, "type": "row", "panels": [
                    {"id": 2, "type": "table", "datasource": {"type": "prometheus", "uid": "old"},
                     "targets": [{"refId": "A", "datasource": "old", "expr": 'up{job="old"}'}]}
                ]}], "annotations": {"list": [{"datasource": {"type": "prometheus", "uid": "old"}}]}}


class ImportDashboardTests(unittest.TestCase):
    def test_nested_panel_target_annotation_mapping_preserves_query_and_ids(self):
        source = dashboard()
        before = copy.deepcopy(source)
        result = prepare_dashboard(source, {"old": "new"})
        self.assertEqual(source, before)
        panel = result["panels"][0]["panels"][0]
        self.assertEqual([result["panels"][0]["id"], panel["id"]], [1, 2])
        self.assertEqual(panel["datasource"], {"type": "prometheus", "uid": "new"})
        self.assertEqual(panel["targets"][0]["datasource"], "new")
        self.assertEqual(panel["targets"][0]["expr"], 'up{job="old"}')
        self.assertEqual(result["annotations"]["list"][0]["datasource"]["uid"], "new")
        self.assertIsNone(result["id"])
        self.assertEqual(result["version"], 1)

    def test_multiple_external_inputs_are_mapped_independently(self):
        source = dashboard()
        source["__inputs"] = [{"name": "DS_ONE", "type": "datasource"}, {"name": "DS_TWO", "type": "datasource"}]
        source["panels"][0]["panels"][0]["datasource"]["uid"] = "${DS_ONE}"
        source["annotations"]["list"][0]["datasource"]["uid"] = "$DS_TWO"
        result = prepare_dashboard(source, {"DS_ONE": "one", "DS_TWO": "two"})
        self.assertEqual(result["panels"][0]["panels"][0]["datasource"]["uid"], "one")
        self.assertEqual(result["annotations"]["list"][0]["datasource"]["uid"], "two")
        self.assertNotIn("__inputs", result)

    def test_unresolved_inputs_and_variables_are_rejected(self):
        source = dashboard()
        source["__inputs"] = [{"name": "DS_ONE", "type": "datasource"}]
        with self.assertRaisesRegex(DashboardError, "missing --datasource"):
            prepare_dashboard(source, {})
        source.pop("__inputs")
        source["panels"][0]["panels"][0]["datasource"]["uid"] = "${UNDECLARED}"
        with self.assertRaisesRegex(DashboardError, "not declared"):
            prepare_dashboard(source, {})

    def test_datasource_variable_and_query_variable_mappings(self):
        source = dashboard()
        source["templating"]["list"] = [
            {"name": "DS_MAIN", "type": "datasource", "query": "prometheus", "current": {"text": "Old", "value": "old"}, "options": [{"value": "old"}]},
            {"name": "host", "type": "query", "datasource": {"type": "prometheus", "uid": "old"}, "query": "label_values(up, instance)"}]
        source["panels"][0]["panels"][0]["datasource"]["uid"] = "${DS_MAIN}"
        result = prepare_dashboard(source, {"old": "new"})
        variable = result["templating"]["list"][0]
        self.assertEqual(variable["current"]["value"], "new")
        self.assertEqual(variable["options"], [])
        self.assertEqual(result["templating"]["list"][1]["datasource"]["uid"], "new")
        self.assertEqual(result["panels"][0]["panels"][0]["datasource"]["uid"], "${DS_MAIN}")

    def test_classic_and_api_exports_supported_but_v2_is_explicit(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "export.json"
            for data in (dashboard(), {"dashboard": dashboard(), "meta": {"folderTitle": "Original"}}):
                path.write_text(json.dumps(data))
                self.assertEqual(load_dashboard(path), dashboard())
            path.write_text(json.dumps({"kind": "Dashboard", "spec": {"elements": {}}}))
            with self.assertRaisesRegex(DashboardError, "Classic"):
                load_dashboard(path)

    def test_no_fixed_count_and_custom_panel_types_allowed(self):
        validate_collection([])
        entries = []
        for i in range(4):
            data = prepare_dashboard(dashboard(f"project-{i}", f"Project {i}"), {})
            data["panels"][0]["panels"][0]["type"] = "third-party-panel"
            entries.append((f"{i}.json", data))
        validate_collection(entries)

    def test_collisions_include_nested_files_and_titles(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            data = prepare_dashboard(dashboard(), {})
            save_dashboard(data, root / "team/one.json", root)
            for other in (prepare_dashboard(dashboard(title="Different"), {}), prepare_dashboard(dashboard(uid="different"), {})):
                with self.assertRaisesRegex(DashboardError, "conflicting"):
                    save_dashboard(other, root / "two.json", root)
            self.assertEqual(len(list(project_dashboards(root))), 1)

    def test_existing_file_requires_overwrite_and_survives_failed_update(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            dest = root / "dashboard.json"
            data = prepare_dashboard(dashboard(), {})
            save_dashboard(data, dest, root)
            before = dest.read_bytes()
            with self.assertRaisesRegex(DashboardError, "already exists"):
                save_dashboard(data, dest, root)
            invalid = copy.deepcopy(data)
            invalid["panels"][0]["panels"][0]["id"] = 1
            with self.assertRaisesRegex(DashboardError, "duplicate panel"):
                save_dashboard(invalid, dest, root, overwrite=True)
            self.assertEqual(before, dest.read_bytes())
            data["title"] = "Updated"
            save_dashboard(data, dest, root, overwrite=True)
            self.assertEqual(json.loads(dest.read_text())["title"], "Updated")

    def test_outside_projects_and_symlink_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "projects"
            root.mkdir()
            outside = Path(directory) / "elsewhere"
            outside.mkdir()
            (root / "link").symlink_to(outside, target_is_directory=True)
            for path in (outside / "bad.json", root / "link/bad.json", root / "bad.yaml"):
                with self.assertRaisesRegex(DashboardError, "inside projects"):
                    save_dashboard(prepare_dashboard(dashboard(), {}), path, root)

    def test_input_validation_and_uid_generation(self):
        for value in ("no-equals", "=target", "source="):
            with self.assertRaises(DashboardError):
                parse_mappings([value])
        with self.assertRaises(DashboardError):
            parse_mappings(["a=b", "a=c"])
        source = dashboard()
        source.pop("uid")
        result = prepare_dashboard(source, {})
        self.assertTrue(result["uid"].startswith("project-"))
        source["__inputs"] = [{"type": "constant", "name": "OTHER"}]
        with self.assertRaisesRegex(DashboardError, "non-datasource"):
            prepare_dashboard(source, {})
